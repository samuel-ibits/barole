<?php
/**
 * Logistics API
 * Handle CRUD operations for logistics
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            handleGetLogistics($db);
            break;
        case 'POST':
            handleCreateLogistics($db);
            break;
        case 'PUT':
            handleUpdateLogistics($db);
            break;
        case 'DELETE':
            handleDeleteLogistics($db);
            break;
        default:
            sendErrorResponse('Method not allowed', 405);
    }

} catch (Exception $e) {
    error_log("Logistics API error: " . $e->getMessage());
    sendErrorResponse('Failed to process logistics request: ' . $e->getMessage());
}

/**
 * Handle GET requests - retrieve logistics
 */
function handleGetLogistics($db) {
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM logistics {$whereClause}";
    $countStmt = $db->query($countQuery, $params);
    $totalResult = $countStmt->fetch();
    $total = $totalResult['total'];
    
    // Get logistics
    $query = "
        SELECT 
            l.*,
            c.name as carrier_name
        FROM logistics l
        LEFT JOIN carriers c ON l.carrier_id = c.id
        {$whereClause}
        ORDER BY l.created_at DESC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->query($query, $params);
    $logistics = $stmt->fetchAll();
    
    // Format data for frontend
    $formattedLogistics = [];
    foreach ($logistics as $log) {
        $formattedLogistics[] = [
            'id' => $log['id'],
            'logistics_id' => $log['logistics_id'],
            'carrier_name' => $log['carrier_name'],
            'origin' => $log['origin'],
            'destination' => $log['destination'],
            'shipping_method' => $log['shipping_method'],
            'departure_date' => $log['departure_date'],
            'arrival_date' => $log['arrival_date'],
            'status' => $log['status'],
            'created_at' => date('Y-m-d H:i', strtotime($log['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedLogistics,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
}

/**
 * Handle POST requests - create new logistics entry
 */
function handleCreateLogistics($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $errors = [];
    $requiredFields = ['logistics_id', 'trade_id', 'carrier_id', 'origin', 'destination'];
    
    foreach ($requiredFields as $field) {
        if (empty($input[$field])) {
            $errors[] = "Field '$field' is required";
        }
    }
    
    // Validate specific field formats
    $logistics_id = trim($input['logistics_id'] ?? '');
    $trade_id = trim($input['trade_id'] ?? '');
    $carrier_id = intval($input['carrier_id'] ?? 0);
    $shipping_method = trim($input['shipping_method'] ?? '');
    $origin = trim($input['origin'] ?? '');
    $destination = trim($input['destination'] ?? '');
    $departure_date = trim($input['departure_date'] ?? '');
    $arrival_date = trim($input['arrival_date'] ?? '');
    $status = trim($input['status'] ?? 'pending');
    $tracking_number = trim($input['tracking_number'] ?? '');
    $documents = $input['documents'] ?? [];
    
    // Validate logistics ID format
    if (!preg_match('/^LOG[0-9]{4}[A-Z0-9]+$/', $logistics_id)) {
        $errors[] = 'Logistics ID must follow format: LOG followed by numbers and letters (e.g., LOG2024001)';
    }
    
    // Validate carrier ID
    if ($carrier_id <= 0) {
        $errors[] = 'Valid carrier ID is required';
    }
    
    // Validate dates
    if (!empty($departure_date) && !validateDate($departure_date)) {
        $errors[] = 'Departure date must be in YYYY-MM-DD format';
    }
    
    if (!empty($arrival_date) && !validateDate($arrival_date)) {
        $errors[] = 'Arrival date must be in YYYY-MM-DD format';
    }
    
    // Validate status
    if (!in_array($status, ['pending', 'in_transit', 'delivered', 'cancelled'])) {
        $errors[] = 'Valid status is required';
    }
    
    if (!empty($errors)) {
        sendErrorResponse('Validation failed: ' . implode(', ', $errors), 400);
        return;
    }
    
    try {
        // Check if logistics_id already exists
        $existingLogistics = $db->fetchOne("SELECT id FROM logistics WHERE logistics_id = ?", [$logistics_id]);
        if ($existingLogistics) {
            sendErrorResponse('Logistics ID already exists', 400);
            return;
        }
        
        // Insert new logistics entry
        $query = "
            INSERT INTO logistics (
                logistics_id, trade_id, carrier_id, shipping_method, origin, destination,
                departure_date, arrival_date, status, tracking_number, documents,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ";
        
        $params = [
            $logistics_id, $trade_id, $carrier_id, $shipping_method, $origin, $destination,
            $departure_date ?: null, $arrival_date ?: null, $status, $tracking_number,
            !empty($documents) ? json_encode($documents) : null
        ];
        
        $result = $db->execute($query, $params);
        
        if ($result) {
            $logisticsDbId = $db->getConnection()->lastInsertId();
            sendJSONResponse([
                'success' => true,
                'message' => 'Logistics entry created successfully',
                'data' => ['id' => $logisticsDbId, 'logistics_id' => $logistics_id]
            ], 201);
        } else {
            sendErrorResponse('Failed to create logistics entry');
        }
        
    } catch (Exception $e) {
        error_log("Create logistics error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle PUT requests - update existing logistics entry
 */
function handleUpdateLogistics($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid logistics ID is required', 400);
        return;
    }
    
    // Check if logistics entry exists
    $existingLogistics = $db->fetchOne("SELECT * FROM logistics WHERE id = ?", [$id]);
    if (!$existingLogistics) {
        sendErrorResponse('Logistics entry not found', 404);
        return;
    }
    
    // Build update query with only provided fields
    $updateFields = [];
    $params = [];
    
    $allowedFields = [
        'trade_id', 'carrier_id', 'shipping_method', 'origin', 'destination',
        'departure_date', 'arrival_date', 'status', 'tracking_number', 'documents'
    ];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            if ($field === 'documents') {
                $updateFields[] = "$field = ?";
                $params[] = !empty($input[$field]) ? json_encode($input[$field]) : null;
            } else {
                $updateFields[] = "$field = ?";
                $params[] = $input[$field];
            }
        }
    }
    
    if (empty($updateFields)) {
        sendErrorResponse('No fields to update', 400);
        return;
    }
    
    // Add updated_at timestamp
    $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
    $params[] = $id;
    
    try {
        $query = "UPDATE logistics SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $result = $db->execute($query, $params);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Logistics entry updated successfully'
            ]);
        } else {
            sendErrorResponse('Failed to update logistics entry');
        }
        
    } catch (Exception $e) {
        error_log("Update logistics error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle DELETE requests - delete logistics entry
 */
function handleDeleteLogistics($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid logistics ID is required', 400);
        return;
    }
    
    try {
        // Check if logistics entry exists
        $existingLogistics = $db->fetchOne("SELECT id, status FROM logistics WHERE id = ?", [$id]);
        if (!$existingLogistics) {
            sendErrorResponse('Logistics entry not found', 404);
            return;
        }
        
        // Prevent deletion of delivered shipments
        if ($existingLogistics['status'] === 'delivered') {
            sendErrorResponse('Cannot delete delivered shipments', 400);
            return;
        }
        
        $result = $db->execute("DELETE FROM logistics WHERE id = ?", [$id]);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Logistics entry deleted successfully'
            ]);
        } else {
            sendErrorResponse('Failed to delete logistics entry');
        }
        
    } catch (Exception $e) {
        error_log("Delete logistics error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}
?> 