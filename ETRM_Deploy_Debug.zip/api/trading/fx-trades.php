<?php
/**
 * FX Trades API
 * Handle CRUD operations for FX trades
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            handleGetFXTrades($db);
            break;
        case 'POST':
            handleCreateFXTrade($db);
            break;
        case 'PUT':
            handleUpdateFXTrade($db);
            break;
        case 'DELETE':
            handleDeleteFXTrade($db);
            break;
        default:
            sendErrorResponse('Method not allowed', 405);
    }

} catch (Exception $e) {
    error_log("FX trades API error: " . $e->getMessage());
    sendErrorResponse('Failed to process FX trades request: ' . $e->getMessage());
}

/**
 * Handle GET requests - retrieve FX trades
 */
function handleGetFXTrades($db) {
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "fx.status = ?";
        $params[] = $status;
    }
    
    if (!empty($search)) {
        $whereConditions[] = "(fx.trade_id LIKE ? OR c.name LIKE ? OR fx.base_currency LIKE ? OR fx.quote_currency LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM fx_trades fx 
                   LEFT JOIN counterparties c ON fx.counterparty_id = c.id
                   LEFT JOIN business_units bu ON fx.business_unit_id = bu.id {$whereClause}";
    $totalResult = $db->fetchOne($countQuery, $params);
    $total = $totalResult['total'];
    
    // Get FX trades
    $query = "
        SELECT 
            fx.*,
            c.name as counterparty_name,
            bu.business_unit_name
        FROM fx_trades fx
        LEFT JOIN counterparties c ON fx.counterparty_id = c.id
        LEFT JOIN business_units bu ON fx.business_unit_id = bu.id
        {$whereClause}
        ORDER BY fx.created_at DESC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->query($query, $params);
    $trades = $stmt->fetchAll();
    
    // Format data for frontend
    $formattedTrades = [];
    foreach ($trades as $trade) {
        $totalValue = $trade['amount'] * $trade['exchange_rate'];
        $formattedTrades[] = [
            'id' => $trade['id'],
            'trade_id' => $trade['trade_id'],
            'counterparty_name' => $trade['counterparty_name'],
            'business_unit_name' => $trade['business_unit_name'],
            'base_currency' => $trade['base_currency'],
            'quote_currency' => $trade['quote_currency'],
            'trade_type' => $trade['trade_type'],
            'amount' => number_format($trade['amount'], 2),
            'exchange_rate' => number_format($trade['exchange_rate'], 6),
            'total_value' => number_format($totalValue, 2),
            'trade_date' => $trade['trade_date'],
            'value_date' => $trade['value_date'],
            'settlement_date' => $trade['settlement_date'],
            'status' => $trade['status'],
            'created_at' => date('Y-m-d H:i', strtotime($trade['created_at'])),
            'updated_at' => date('Y-m-d H:i', strtotime($trade['updated_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedTrades,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
}

/**
 * Handle POST requests - create new FX trade
 */
function handleCreateFXTrade($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $errors = [];
    $requiredFields = ['trade_id', 'base_currency', 'quote_currency', 'trade_type', 'amount', 'exchange_rate', 'counterparty_id', 'business_unit_id'];
    
    foreach ($requiredFields as $field) {
        if (empty($input[$field])) {
            $errors[] = "Field '$field' is required";
        }
    }
    
    // Validate specific field formats
    $trade_id = trim($input['trade_id'] ?? '');
    $base_currency = trim($input['base_currency'] ?? '');
    $quote_currency = trim($input['quote_currency'] ?? '');
    $trade_type = trim($input['trade_type'] ?? '');
    $amount = floatval($input['amount'] ?? 0);
    $exchange_rate = floatval($input['exchange_rate'] ?? 0);
    $settlement_date = trim($input['settlement_date'] ?? '');
    $trade_date = trim($input['trade_date'] ?? '');
    $value_date = trim($input['value_date'] ?? '');
    $counterparty_id = intval($input['counterparty_id'] ?? 0);
    $business_unit_id = intval($input['business_unit_id'] ?? 0);
    $status = trim($input['status'] ?? 'pending');
    
    // Validate trade ID format
    if (!preg_match('/^FX[0-9]{4}[A-Z0-9]+$/', $trade_id)) {
        $errors[] = 'Trade ID must follow format: FX followed by numbers and letters (e.g., FX2024001)';
    }
    
    // Validate trade type
    if (!in_array($trade_type, ['buy', 'sell'])) {
        $errors[] = 'Valid trade type is required (buy, sell)';
    }
    
    // Validate currency codes (3 letters)
    if (!preg_match('/^[A-Z]{3}$/', $base_currency)) {
        $errors[] = 'Base currency must be a 3-letter code (e.g., USD)';
    }
    
    if (!preg_match('/^[A-Z]{3}$/', $quote_currency)) {
        $errors[] = 'Quote currency must be a 3-letter code (e.g., EUR)';
    }
    
    if ($base_currency === $quote_currency) {
        $errors[] = 'Base and quote currencies must be different';
    }
    
    // Validate numeric values
    if ($amount <= 0) {
        $errors[] = 'Amount must be greater than 0';
    }
    
    if ($exchange_rate <= 0) {
        $errors[] = 'Exchange rate must be greater than 0';
    }
    
    // Validate dates
    if (!empty($settlement_date) && !validateDate($settlement_date)) {
        $errors[] = 'Settlement date must be in YYYY-MM-DD format';
    }
    
    if (!empty($trade_date) && !validateDate($trade_date)) {
        $errors[] = 'Trade date must be in YYYY-MM-DD format';
    }
    
    if (!empty($value_date) && !validateDate($value_date)) {
        $errors[] = 'Value date must be in YYYY-MM-DD format';
    }
    
    // Validate status
    if (!in_array($status, ['pending', 'confirmed', 'executed', 'settled', 'cancelled'])) {
        $errors[] = 'Valid status is required';
    }
    
    if (!empty($errors)) {
        sendErrorResponse('Validation failed: ' . implode(', ', $errors), 400);
        return;
    }
    
    try {
        // Check if trade_id already exists
        $existingTrade = $db->fetchOne("SELECT id FROM fx_trades WHERE trade_id = ?", [$trade_id]);
        if ($existingTrade) {
            sendErrorResponse('Trade ID already exists', 400);
            return;
        }
        
        // Set trader_id to current user
        $trader_id = $_SESSION['user_id'];
        
        // Set default dates if not provided
        if (empty($trade_date)) {
            $trade_date = date('Y-m-d');
        }
        if (empty($value_date)) {
            $value_date = date('Y-m-d', strtotime('+2 days')); // T+2 settlement
        }
        
        // Insert new FX trade
        $query = "
            INSERT INTO fx_trades (
                trade_id, base_currency, quote_currency, trade_type, amount, exchange_rate,
                settlement_date, trade_date, value_date, counterparty_id, business_unit_id,
                trader_id, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ";
        
        $params = [
            $trade_id, $base_currency, $quote_currency, $trade_type, $amount, $exchange_rate,
            $settlement_date ?: null, $trade_date, $value_date, $counterparty_id, $business_unit_id,
            $trader_id, $status
        ];
        
        $result = $db->execute($query, $params);
        
        if ($result) {
            $tradeId = $db->getConnection()->lastInsertId();
            sendJSONResponse([
                'success' => true,
                'message' => 'FX trade created successfully',
                'data' => ['id' => $tradeId, 'trade_id' => $trade_id]
            ], 201);
        } else {
            sendErrorResponse('Failed to create FX trade');
        }
        
    } catch (Exception $e) {
        error_log("Create FX trade error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle PUT requests - update existing FX trade
 */
function handleUpdateFXTrade($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid trade ID is required', 400);
        return;
    }
    
    // Check if trade exists
    $existingTrade = $db->fetchOne("SELECT * FROM fx_trades WHERE id = ?", [$id]);
    if (!$existingTrade) {
        sendErrorResponse('FX trade not found', 404);
        return;
    }
    
    // Build update query with only provided fields
    $updateFields = [];
    $params = [];
    
    $allowedFields = [
        'base_currency', 'quote_currency', 'trade_type', 'amount', 'exchange_rate',
        'settlement_date', 'trade_date', 'value_date', 'counterparty_id', 
        'business_unit_id', 'status'
    ];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateFields[] = "$field = ?";
            $params[] = $input[$field];
        }
    }
    
    if (empty($updateFields)) {
        sendErrorResponse('No fields to update', 400);
        return;
    }
    
    // Add updated_at timestamp
    $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
    $params[] = $id;
    
    try {
        $query = "UPDATE fx_trades SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $result = $db->execute($query, $params);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'FX trade updated successfully'
            ]);
        } else {
            sendErrorResponse('Failed to update FX trade');
        }
        
    } catch (Exception $e) {
        error_log("Update FX trade error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle DELETE requests - delete FX trade
 */
function handleDeleteFXTrade($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid trade ID is required', 400);
        return;
    }
    
    try {
        // Check if trade exists
        $existingTrade = $db->fetchOne("SELECT id, status FROM fx_trades WHERE id = ?", [$id]);
        if (!$existingTrade) {
            sendErrorResponse('FX trade not found', 404);
            return;
        }
        
        // Prevent deletion of executed or settled trades
        if (in_array($existingTrade['status'], ['executed', 'settled'])) {
            sendErrorResponse('Cannot delete executed or settled trades', 400);
            return;
        }
        
        $result = $db->execute("DELETE FROM fx_trades WHERE id = ?", [$id]);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'FX trade deleted successfully'
            ]);
        } else {
            sendErrorResponse('Failed to delete FX trade');
        }
        
    } catch (Exception $e) {
        error_log("Delete FX trade error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}
?> 