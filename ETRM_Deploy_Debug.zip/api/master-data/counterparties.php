<?php
/**
 * Counterparties API
 * Get counterparties data for master data module
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

// Handle different HTTP methods
$method = $_SERVER['REQUEST_METHOD'];

try {
    $db = getDB();

    if ($method === 'POST') {
        // Handle create new counterparty
        handleCreateCounterparty($db);
        return;
    }
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($search)) {
        $whereConditions[] = "(name LIKE ? OR code LIKE ? OR email LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    if (!empty($status)) {
        $whereConditions[] = "status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM counterparties {$whereClause}";
    $totalResult = $db->fetchOne($countQuery, $params);
    $total = $totalResult['total'];
    
    // Get counterparties
    $query = "
        SELECT 
            id, code, name, credit_rating, exposure_limit, 
            country, address, contact_person, email, phone,
            tax_id, registration_number, status, created_at, updated_at
        FROM counterparties 
        {$whereClause}
        ORDER BY name
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $counterparties = $db->fetchAll($query, $params);
    
    // Format data for frontend
    $formattedCounterparties = [];
    foreach ($counterparties as $counterparty) {
        $formattedCounterparties[] = [
            'id' => $counterparty['id'],
            'code' => $counterparty['code'],
            'name' => $counterparty['name'],
            'credit_rating' => $counterparty['credit_rating'],
            'exposure_limit' => $counterparty['exposure_limit'] ? number_format($counterparty['exposure_limit'], 2) : '-',
            'country' => $counterparty['country'],
            'contact_person' => $counterparty['contact_person'],
            'email' => $counterparty['email'],
            'phone' => $counterparty['phone'],
            'status' => $counterparty['status'],
            'created_at' => date('Y-m-d H:i', strtotime($counterparty['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedCounterparties,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
    
} catch (Exception $e) {
    error_log("Counterparties API error: " . $e->getMessage());
    sendErrorResponse('Failed to load counterparties data');
}

function handleCreateCounterparty($db) {
    try {
        // Get POST data
        $code = $_POST['code'] ?? '';
        $name = $_POST['name'] ?? '';
        $type = $_POST['type'] ?? '';
        $country = $_POST['country'] ?? '';
        $email = $_POST['email'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $address = $_POST['address'] ?? '';
        
        // Validation
        if (empty($code) || empty($name) || empty($type) || empty($country)) {
            sendErrorResponse('Code, name, type, and country are required');
            return;
        }
        
        // Check if code already exists
        $existingStmt = $db->query("SELECT id FROM counterparties WHERE code = ?", [$code]);
        if ($existingStmt->fetch()) {
            sendErrorResponse('Counterparty code already exists');
            return;
        }
        
        // Insert new counterparty
        $query = "
            INSERT INTO counterparties (
                code, name, type, country, email, phone, address, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ";
        
        $params = [$code, $name, $type, $country, $email, $phone, $address, 'active'];
        
        $stmt = $db->query($query, $params);
        
        if ($stmt->rowCount() > 0) {
            $newId = $db->getPDO()->lastInsertId();
            
            // Log activity
            logUserActivity(getCurrentUserId(), 'create_counterparty', "Created counterparty: {$code}");
            
            sendJSONResponse([
                'success' => true,
                'message' => 'Counterparty created successfully',
                'data' => ['id' => $newId, 'code' => $code]
            ]);
        } else {
            sendErrorResponse('Failed to create counterparty');
        }
        
    } catch (Exception $e) {
        error_log("Create counterparty error: " . $e->getMessage());
        sendErrorResponse('Failed to create counterparty: ' . $e->getMessage());
    }
}
?> 