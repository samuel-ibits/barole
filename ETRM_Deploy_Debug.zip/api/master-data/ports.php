<?php
/**
 * Ports API
 * Get ports data for master data module
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "active_status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM ports {$whereClause}";
    $countStmt = $db->query($countQuery, $params);
    $totalResult = $countStmt->fetch();
    $total = $totalResult['total'];
    
    // Get ports
    $query = "
        SELECT 
            p.*
        FROM ports p
        {$whereClause}
        ORDER BY p.port_name ASC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->query($query, $params);
    $ports = $stmt->fetchAll();
    
    // Format data for frontend
    $formattedPorts = [];
    foreach ($ports as $port) {
        $formattedPorts[] = [
            'id' => $port['id'],
            'code' => $port['code'],
            'port_name' => $port['port_name'],
            'city' => $port['city'],
            'country' => $port['country'],
            'facilities' => $port['facilities'],
            'status' => $port['active_status'],
            'created_at' => date('Y-m-d H:i', strtotime($port['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedPorts,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
    
} catch (Exception $e) {
    error_log("Ports API error: " . $e->getMessage());
    sendErrorResponse('Failed to load ports data');
}
?> 