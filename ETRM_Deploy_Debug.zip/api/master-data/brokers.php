<?php
/**
 * Brokers API
 * Get brokers data for master data module
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM brokers {$whereClause}";
    $countStmt = $db->query($countQuery, $params);
    $totalResult = $countStmt->fetch();
    $total = $totalResult['total'];
    
    // Get brokers
    $query = "
        SELECT 
            b.*
        FROM brokers b
        {$whereClause}
        ORDER BY b.name ASC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->query($query, $params);
    $brokers = $stmt->fetchAll();
    
    // Format data for frontend
    $formattedBrokers = [];
    foreach ($brokers as $broker) {
        $formattedBrokers[] = [
            'id' => $broker['id'],
            'code' => $broker['code'],
            'name' => $broker['name'],
            'exchange' => $broker['exchange'],
            'commission_rate' => number_format($broker['commission_rate'], 2) . '%',
            'contact_person' => $broker['contact_person'],
            'email' => $broker['email'],
            'phone' => $broker['phone'],
            'status' => $broker['status'],
            'created_at' => date('Y-m-d H:i', strtotime($broker['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedBrokers,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
    
} catch (Exception $e) {
    error_log("Brokers API error: " . $e->getMessage());
    sendErrorResponse('Failed to load brokers data');
}
?> 