<?php
/**
 * Carriers API
 * Get carriers data for master data module
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM carriers {$whereClause}";
    $countStmt = $db->query($countQuery, $params);
    $totalResult = $countStmt->fetch();
    $total = $totalResult['total'];
    
    // Get carriers
    $query = "
        SELECT 
            c.*
        FROM carriers c
        {$whereClause}
        ORDER BY c.name ASC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->query($query, $params);
    $carriers = $stmt->fetchAll();
    
    // Format data for frontend
    $formattedCarriers = [];
    foreach ($carriers as $carrier) {
        $formattedCarriers[] = [
            'id' => $carrier['id'],
            'code' => $carrier['code'],
            'name' => $carrier['name'],
            'contact_person' => $carrier['contact_person'],
            'email' => $carrier['email'],
            'phone' => $carrier['phone'],
            'status' => $carrier['status'],
            'created_at' => date('Y-m-d H:i', strtotime($carrier['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedCarriers,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
    
} catch (Exception $e) {
    error_log("Carriers API error: " . $e->getMessage());
    sendErrorResponse('Failed to load carriers data');
}
?> 