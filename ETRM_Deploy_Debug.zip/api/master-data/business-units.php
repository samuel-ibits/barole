<?php
/**
 * Business Units API
 * Handle CRUD operations for business units
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            handleGetBusinessUnits($db);
            break;
        case 'POST':
            handleCreateBusinessUnit($db);
            break;
        case 'PUT':
            handleUpdateBusinessUnit($db);
            break;
        case 'DELETE':
            handleDeleteBusinessUnit($db);
            break;
        default:
            sendErrorResponse('Method not allowed', 405);
    }

} catch (Exception $e) {
    error_log("Business Units API error: " . $e->getMessage());
    sendErrorResponse('Failed to process business units request: ' . $e->getMessage());
}

/**
 * Handle GET requests - retrieve business units
 */
function handleGetBusinessUnits($db) {
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($search)) {
        $whereConditions[] = "(business_unit_name LIKE ? OR code LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    if (!empty($status)) {
        $whereConditions[] = "active_status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM business_units {$whereClause}";
    $totalResult = $db->fetchOne($countQuery, $params);
    $total = $totalResult['total'];
    
    // Get business units
    $query = "
        SELECT 
            id, code, business_unit_name, parent_unit_id, 
            manager_id, active_status, created_at, updated_at
        FROM business_units 
        {$whereClause}
        ORDER BY business_unit_name
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $businessUnits = $db->fetchAll($query, $params);
    
    // Format data for frontend
    $formattedBusinessUnits = [];
    foreach ($businessUnits as $bu) {
        $formattedBusinessUnits[] = [
            'id' => $bu['id'],
            'code' => $bu['code'],
            'business_unit_name' => $bu['business_unit_name'],
            'parent_unit_id' => $bu['parent_unit_id'],
            'manager_id' => $bu['manager_id'],
            'status' => $bu['active_status'],
            'created_at' => date('Y-m-d H:i', strtotime($bu['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedBusinessUnits,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
}

/**
 * Handle POST requests - create new business unit
 */
function handleCreateBusinessUnit($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $errors = [];
    $requiredFields = ['code', 'business_unit_name'];
    
    foreach ($requiredFields as $field) {
        if (empty($input[$field])) {
            $errors[] = "Field '$field' is required";
        }
    }
    
    // Validate specific field formats
    $code = trim($input['code'] ?? '');
    $business_unit_name = trim($input['business_unit_name'] ?? '');
    $parent_unit_id = !empty($input['parent_unit_id']) ? intval($input['parent_unit_id']) : null;
    $manager_id = !empty($input['manager_id']) ? intval($input['manager_id']) : null;
    $active_status = trim($input['active_status'] ?? 'active');
    
    // Validate code format (alphanumeric, no spaces)
    if (!preg_match('/^[A-Z0-9_-]+$/', $code)) {
        $errors[] = 'Business unit code must be alphanumeric with hyphens/underscores only (e.g., NORTH-AMERICA)';
    }
    
    // Validate business unit name length
    if (strlen($business_unit_name) < 3 || strlen($business_unit_name) > 100) {
        $errors[] = 'Business unit name must be between 3 and 100 characters';
    }
    
    // Validate active status
    if (!in_array($active_status, ['active', 'inactive'])) {
        $errors[] = 'Valid active status is required (active, inactive)';
    }
    
    // Validate parent unit (if provided)
    if ($parent_unit_id !== null) {
        $parentUnit = $db->fetchOne("SELECT id FROM business_units WHERE id = ?", [$parent_unit_id]);
        if (!$parentUnit) {
            $errors[] = 'Parent unit ID does not exist';
        }
    }
    
    // Validate manager (if provided)
    if ($manager_id !== null) {
        $manager = $db->fetchOne("SELECT id FROM users WHERE id = ?", [$manager_id]);
        if (!$manager) {
            $errors[] = 'Manager ID does not exist';
        }
    }
    
    if (!empty($errors)) {
        sendErrorResponse('Validation failed: ' . implode(', ', $errors), 400);
        return;
    }
    
    try {
        // Check if code already exists
        $existingUnit = $db->fetchOne("SELECT id FROM business_units WHERE code = ?", [$code]);
        if ($existingUnit) {
            sendErrorResponse('Business unit code already exists', 400);
            return;
        }
        
        // Insert new business unit
        $query = "
            INSERT INTO business_units (
                code, business_unit_name, parent_unit_id, manager_id, active_status,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ";
        
        $params = [$code, $business_unit_name, $parent_unit_id, $manager_id, $active_status];
        
        $result = $db->execute($query, $params);
        
        if ($result) {
            $unitId = $db->getConnection()->lastInsertId();
            sendJSONResponse([
                'success' => true,
                'message' => 'Business unit created successfully',
                'data' => ['id' => $unitId, 'code' => $code]
            ], 201);
        } else {
            sendErrorResponse('Failed to create business unit');
        }
        
    } catch (Exception $e) {
        error_log("Create business unit error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle PUT requests - update existing business unit
 */
function handleUpdateBusinessUnit($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid business unit ID is required', 400);
        return;
    }
    
    // Check if business unit exists
    $existingUnit = $db->fetchOne("SELECT * FROM business_units WHERE id = ?", [$id]);
    if (!$existingUnit) {
        sendErrorResponse('Business unit not found', 404);
        return;
    }
    
    // Build update query with only provided fields
    $updateFields = [];
    $params = [];
    
    $allowedFields = ['business_unit_name', 'parent_unit_id', 'manager_id', 'active_status'];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateFields[] = "$field = ?";
            $params[] = $input[$field];
        }
    }
    
    if (empty($updateFields)) {
        sendErrorResponse('No fields to update', 400);
        return;
    }
    
    // Validate parent unit circular reference
    if (isset($input['parent_unit_id']) && !empty($input['parent_unit_id'])) {
        $parentId = intval($input['parent_unit_id']);
        if ($parentId === $id) {
            sendErrorResponse('Business unit cannot be its own parent', 400);
            return;
        }
        
        // Check for circular references (prevent infinite loops)
        $checkParent = $parentId;
        $depth = 0;
        while ($checkParent && $depth < 10) {
            $parent = $db->fetchOne("SELECT parent_unit_id FROM business_units WHERE id = ?", [$checkParent]);
            if ($parent && $parent['parent_unit_id'] == $id) {
                sendErrorResponse('Circular reference detected in parent hierarchy', 400);
                return;
            }
            $checkParent = $parent ? $parent['parent_unit_id'] : null;
            $depth++;
        }
    }
    
    // Add updated_at timestamp
    $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
    $params[] = $id;
    
    try {
        $query = "UPDATE business_units SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $result = $db->execute($query, $params);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Business unit updated successfully'
            ]);
        } else {
            sendErrorResponse('Failed to update business unit');
        }
        
    } catch (Exception $e) {
        error_log("Update business unit error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle DELETE requests - delete business unit
 */
function handleDeleteBusinessUnit($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid business unit ID is required', 400);
        return;
    }
    
    try {
        // Check if business unit exists
        $existingUnit = $db->fetchOne("SELECT id, business_unit_name FROM business_units WHERE id = ?", [$id]);
        if (!$existingUnit) {
            sendErrorResponse('Business unit not found', 404);
            return;
        }
        
        // Check if business unit has child units
        $childUnits = $db->fetchOne("SELECT COUNT(*) as count FROM business_units WHERE parent_unit_id = ?", [$id]);
        if ($childUnits['count'] > 0) {
            sendErrorResponse('Cannot delete business unit that has child units', 400);
            return;
        }
        
        // Check if business unit is referenced in trades
        $tradeReferences = $db->fetchOne("
            SELECT COUNT(*) as count FROM (
                SELECT business_unit_id FROM financial_trades WHERE business_unit_id = ?
                UNION ALL
                SELECT business_unit_id FROM fx_trades WHERE business_unit_id = ?
            ) as references
        ", [$id, $id]);
        
        if ($tradeReferences['count'] > 0) {
            sendErrorResponse('Cannot delete business unit that is referenced in trades', 400);
            return;
        }
        
        $result = $db->execute("DELETE FROM business_units WHERE id = ?", [$id]);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Business unit deleted successfully'
            ]);
        } else {
            sendErrorResponse('Failed to delete business unit');
        }
        
    } catch (Exception $e) {
        error_log("Delete business unit error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}
?> 