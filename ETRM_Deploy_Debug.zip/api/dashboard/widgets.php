<?php
/**
 * Dashboard Widgets API
 * Get dashboard widget data
 */

// Load configuration
require_once __DIR__ . '/../../config/app.php';

// Set JSON response header
header('Content-Type: application/json');

// Check authentication
requireAuth();

try {
    // Sample dashboard widget data
    $widgets = [
        [
            'title' => 'Total Trades',
            'value' => '1,234',
            'change' => 5.2,
            'icon' => 'bi-graph-up'
        ],
        [
            'title' => 'Portfolio Value',
            'value' => '$45.2M',
            'change' => -2.1,
            'icon' => 'bi-currency-dollar'
        ],
        [
            'title' => 'Risk Level',
            'value' => 'Medium',
            'change' => 0,
            'icon' => 'bi-shield-check'
        ],
        [
            'title' => 'Active Alerts',
            'value' => '3',
            'change' => 50,
            'icon' => 'bi-exclamation-triangle'
        ]
    ];
    
    sendSuccessResponse($widgets);
    
} catch (Exception $e) {
    sendErrorResponse('Failed to load dashboard widgets: ' . $e->getMessage());
}
?> 