<?php
/**
 * Application Configuration - Production Version for cPanel
 * ETRM System - Main application settings
 */

// Application settings
define('APP_NAME', 'ETRM System');
define('APP_VERSION', '2.0.0');
define('APP_ENV', 'production'); // Changed to production

// Paths
define('BASE_PATH', dirname(__DIR__));
define('CONFIG_PATH', BASE_PATH . '/config');
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('TEMPLATES_PATH', BASE_PATH . '/templates');
define('ASSETS_PATH', BASE_PATH . '/assets');
define('UPLOADS_PATH', BASE_PATH . '/uploads');
define('LOGS_PATH', BASE_PATH . '/logs');

// URL settings - Dynamic detection for cPanel
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
define('BASE_URL', $protocol . $host);
define('API_URL', BASE_URL . '/api');

// Session settings
define('SESSION_LIFETIME', 3600); // 1 hour
define('SESSION_NAME', 'ETRM_SESSION');
define('SESSION_SECURE', true); // Force HTTPS in production
define('SESSION_HTTPONLY', true);
define('SESSION_SAMESITE', 'Strict');

// Security settings
define('CSRF_TOKEN_LIFETIME', 3600);
define('PASSWORD_MIN_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes
define('ENCRYPTION_KEY', 'CHANGE_THIS_IN_PRODUCTION_' . hash('sha256', __DIR__));

// File upload settings
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_UPLOAD_TYPES', ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt']);

// Database settings (will be loaded from database.php)
define('DB_CONNECTION_TIMEOUT', 30);
define('DB_CHARSET', 'utf8mb4');

// Logging settings
define('LOG_LEVEL', 'ERROR'); // Only log errors in production
define('LOG_MAX_SIZE', 10 * 1024 * 1024); // 10MB
define('LOG_MAX_FILES', 5);

// Cache settings
define('CACHE_ENABLED', true);
define('CACHE_LIFETIME', 3600); // 1 hour
define('CACHE_PATH', BASE_PATH . '/cache');

// Email settings (configure for your hosting)
define('MAIL_HOST', 'localhost');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', '');
define('MAIL_PASSWORD', '');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'noreply@yourdomain.com');
define('MAIL_FROM_NAME', APP_NAME);

// API settings
define('API_RATE_LIMIT', 100); // requests per minute
define('API_TIMEOUT', 30); // seconds

// Report settings
define('REPORT_MAX_RECORDS', 10000);
define('REPORT_TIMEOUT', 300); // 5 minutes
define('REPORT_FORMATS', ['pdf', 'excel', 'csv']);

// Dashboard refresh intervals (in seconds)
define('DASHBOARD_REFRESH_INTERVALS', [
    'widgets' => 300,    // 5 minutes
    'charts' => 600,     // 10 minutes
    'alerts' => 120      // 2 minutes
]);

// Risk management settings
define('RISK_ALERT_THRESHOLD', 0.8);
define('POSITION_LIMIT_WARNING', 0.9);
define('VAR_CONFIDENCE_LEVEL', 0.95);

// Trading settings
define('TRADE_ID_PREFIX', 'TRD');
define('INVOICE_ID_PREFIX', 'INV');
define('SETTLEMENT_ID_PREFIX', 'STL');

// Backup settings
define('BACKUP_ENABLED', false); // Disable in shared hosting
define('BACKUP_RETENTION_DAYS', 30);
define('BACKUP_PATH', BASE_PATH . '/backups');

// System maintenance
define('MAINTENANCE_MODE', false);
define('MAINTENANCE_MESSAGE', 'System is under maintenance. Please try again later.');

// Include required files
require_once CONFIG_PATH . '/database.php';
require_once INCLUDES_PATH . '/functions.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/session.php';

// Initialize secure session
initSecureSession();
?> 