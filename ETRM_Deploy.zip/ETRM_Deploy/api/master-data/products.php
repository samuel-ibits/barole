<?php
/**
 * Products API
 * Handle CRUD operations for products
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            handleGetProducts($db);
            break;
        case 'POST':
            handleCreateProduct($db);
            break;
        case 'PUT':
            handleUpdateProduct($db);
            break;
        case 'DELETE':
            handleDeleteProduct($db);
            break;
        default:
            sendErrorResponse('Method not allowed', 405);
    }

} catch (Exception $e) {
    error_log("Products API error: " . $e->getMessage());
    sendErrorResponse('Failed to process products request: ' . $e->getMessage());
}

/**
 * Handle GET requests - retrieve products
 */
function handleGetProducts($db) {
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $category = isset($_GET['category']) ? trim($_GET['category']) : '';
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($search)) {
        $whereConditions[] = "(product_name LIKE ? OR code LIKE ? OR description LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    if (!empty($category)) {
        $whereConditions[] = "category = ?";
        $params[] = $category;
    }
    
    if (!empty($status)) {
        $whereConditions[] = "active_status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM products {$whereClause}";
    $totalResult = $db->fetchOne($countQuery, $params);
    $total = $totalResult['total'];
    
    // Get products
    $query = "
        SELECT 
            id, code, product_name, category, unit_of_measure, 
            description, active_status, created_at, updated_at
        FROM products 
        {$whereClause}
        ORDER BY product_name
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $products = $db->fetchAll($query, $params);
    
    // Format data for frontend
    $formattedProducts = [];
    foreach ($products as $product) {
        $formattedProducts[] = [
            'id' => $product['id'],
            'code' => $product['code'],
            'product_name' => $product['product_name'],
            'category' => $product['category'],
            'unit_of_measure' => $product['unit_of_measure'],
            'description' => $product['description'],
            'status' => $product['active_status'],
            'created_at' => date('Y-m-d H:i', strtotime($product['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedProducts,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
}

/**
 * Handle POST requests - create new product
 */
function handleCreateProduct($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $errors = [];
    $requiredFields = ['code', 'product_name', 'category', 'unit_of_measure'];
    
    foreach ($requiredFields as $field) {
        if (empty($input[$field])) {
            $errors[] = "Field '$field' is required";
        }
    }
    
    // Validate specific field formats
    $code = trim($input['code'] ?? '');
    $product_name = trim($input['product_name'] ?? '');
    $category = trim($input['category'] ?? '');
    $unit_of_measure = trim($input['unit_of_measure'] ?? '');
    $description = trim($input['description'] ?? '');
    $active_status = trim($input['active_status'] ?? 'active');
    
    // Validate code format (alphanumeric, no spaces)
    if (!preg_match('/^[A-Z0-9_-]+$/', $code)) {
        $errors[] = 'Product code must be alphanumeric with hyphens/underscores only (e.g., CRUDE-WTI)';
    }
    
    // Validate product name length
    if (strlen($product_name) < 3 || strlen($product_name) > 100) {
        $errors[] = 'Product name must be between 3 and 100 characters';
    }
    
    // Validate category
    $validCategories = ['crude_oil', 'natural_gas', 'refined_products', 'petrochemicals', 'power', 'coal', 'renewables'];
    if (!in_array($category, $validCategories)) {
        $errors[] = 'Valid category is required: ' . implode(', ', $validCategories);
    }
    
    // Validate unit of measure
    $validUnits = ['barrel', 'mmbtu', 'gallon', 'liter', 'metric_ton', 'mwh', 'short_ton'];
    if (!in_array($unit_of_measure, $validUnits)) {
        $errors[] = 'Valid unit of measure is required: ' . implode(', ', $validUnits);
    }
    
    // Validate active status
    if (!in_array($active_status, ['active', 'inactive'])) {
        $errors[] = 'Valid active status is required (active, inactive)';
    }
    
    if (!empty($errors)) {
        sendErrorResponse('Validation failed: ' . implode(', ', $errors), 400);
        return;
    }
    
    try {
        // Check if code already exists
        $existingProduct = $db->fetchOne("SELECT id FROM products WHERE code = ?", [$code]);
        if ($existingProduct) {
            sendErrorResponse('Product code already exists', 400);
            return;
        }
        
        // Insert new product
        $query = "
            INSERT INTO products (
                code, product_name, category, unit_of_measure, description, active_status,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ";
        
        $params = [$code, $product_name, $category, $unit_of_measure, $description, $active_status];
        
        $result = $db->execute($query, $params);
        
        if ($result) {
            $productId = $db->getConnection()->lastInsertId();
            sendJSONResponse([
                'success' => true,
                'message' => 'Product created successfully',
                'data' => ['id' => $productId, 'code' => $code]
            ], 201);
        } else {
            sendErrorResponse('Failed to create product');
        }
        
    } catch (Exception $e) {
        error_log("Create product error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle PUT requests - update existing product
 */
function handleUpdateProduct($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid product ID is required', 400);
        return;
    }
    
    // Check if product exists
    $existingProduct = $db->fetchOne("SELECT * FROM products WHERE id = ?", [$id]);
    if (!$existingProduct) {
        sendErrorResponse('Product not found', 404);
        return;
    }
    
    // Build update query with only provided fields
    $updateFields = [];
    $params = [];
    
    $allowedFields = ['product_name', 'category', 'unit_of_measure', 'description', 'active_status'];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateFields[] = "$field = ?";
            $params[] = $input[$field];
        }
    }
    
    if (empty($updateFields)) {
        sendErrorResponse('No fields to update', 400);
        return;
    }
    
    // Add updated_at timestamp
    $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
    $params[] = $id;
    
    try {
        $query = "UPDATE products SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $result = $db->execute($query, $params);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Product updated successfully'
            ]);
        } else {
            sendErrorResponse('Failed to update product');
        }
        
    } catch (Exception $e) {
        error_log("Update product error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle DELETE requests - delete product
 */
function handleDeleteProduct($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid product ID is required', 400);
        return;
    }
    
    try {
        // Check if product exists
        $existingProduct = $db->fetchOne("SELECT id, product_name FROM products WHERE id = ?", [$id]);
        if (!$existingProduct) {
            sendErrorResponse('Product not found', 404);
            return;
        }
        
        // Check if product is referenced in trades (prevent deletion if in use)
        $tradeReferences = $db->fetchOne("
            SELECT COUNT(*) as count FROM (
                SELECT commodity_id FROM financial_trades WHERE commodity_id = ?
                UNION ALL
                SELECT product_id FROM portfolio_positions WHERE product_id = ?
            ) as references
        ", [$id, $id]);
        
        if ($tradeReferences['count'] > 0) {
            sendErrorResponse('Cannot delete product that is referenced in trades or positions', 400);
            return;
        }
        
        $result = $db->execute("DELETE FROM products WHERE id = ?", [$id]);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Product deleted successfully'
            ]);
        } else {
            sendErrorResponse('Failed to delete product');
        }
        
    } catch (Exception $e) {
        error_log("Delete product error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}
?> 