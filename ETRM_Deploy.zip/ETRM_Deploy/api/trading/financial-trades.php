<?php
/**
 * Financial Trades API
 * Complete CRUD operations for financial trades
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

// Handle different HTTP methods
$method = $_SERVER['REQUEST_METHOD'];

try {
    $db = getDB();

    switch ($method) {
        case 'POST':
            handleCreateFinancialTrade($db);
            break;
        case 'PUT':
            handleUpdateFinancialTrade($db);
            break;
        case 'DELETE':
            handleDeleteFinancialTrade($db);
            break;
        default:
            handleGetFinancialTrades($db);
    }

} catch (Exception $e) {
    error_log("Financial trades API error: " . $e->getMessage());
    sendErrorResponse('Failed to process financial trades request: ' . $e->getMessage());
}

/**
 * Handle GET requests - retrieve financial trades
 */
function handleGetFinancialTrades($db) {
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "ft.status = ?";
        $params[] = $status;
    }
    
    if (!empty($search)) {
        $whereConditions[] = "(ft.trade_id LIKE ? OR c.name LIKE ? OR p.product_name LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM financial_trades ft 
                   LEFT JOIN counterparties c ON ft.counterparty_id = c.id
                   LEFT JOIN products p ON ft.commodity_id = p.id {$whereClause}";
    $totalResult = $db->fetchOne($countQuery, $params);
    $total = $totalResult['total'];
    
    // Get financial trades
    $query = "
        SELECT 
            ft.*,
            c.name as counterparty_name,
            p.product_name as commodity_name,
            bu.business_unit_name,
            u.full_name as trader_name,
            (ft.quantity * ft.price) as total_value
        FROM financial_trades ft
        LEFT JOIN counterparties c ON ft.counterparty_id = c.id
        LEFT JOIN products p ON ft.commodity_id = p.id
        LEFT JOIN business_units bu ON ft.business_unit_id = bu.id
        LEFT JOIN users u ON ft.trader_id = u.id
        {$whereClause}
        ORDER BY ft.created_at DESC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $trades = $db->fetchAll($query, $params);
    
    // Format data for frontend
    $formattedTrades = [];
    foreach ($trades as $trade) {
        $formattedTrades[] = [
            'id' => $trade['id'],
            'trade_id' => $trade['trade_id'],
            'counterparty_name' => $trade['counterparty_name'],
            'commodity_name' => $trade['commodity_name'],
            'business_unit_name' => $trade['business_unit_name'],
            'trader_name' => $trade['trader_name'],
            'quantity' => number_format($trade['quantity'], 2),
            'price' => number_format($trade['price'], 2),
            'currency' => $trade['currency'],
            'total_value' => number_format($trade['total_value'], 2),
            'trade_type' => $trade['trade_type'],
            'contract_type' => $trade['contract_type'],
            'settlement_date' => $trade['settlement_date'],
            'margin_requirement' => $trade['margin_requirement'] ? number_format($trade['margin_requirement'], 2) : null,
            'exchange' => $trade['exchange'],
            'contract_month' => $trade['contract_month'],
            'strike_price' => $trade['strike_price'] ? number_format($trade['strike_price'], 2) : null,
            'option_type' => $trade['option_type'],
            'premium' => $trade['premium'] ? number_format($trade['premium'], 2) : null,
            'status' => $trade['status'],
            'created_at' => date('Y-m-d H:i', strtotime($trade['created_at'])),
            'updated_at' => date('Y-m-d H:i', strtotime($trade['updated_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedTrades,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
}

/**
 * Handle POST requests - create new financial trade
 */
function handleCreateFinancialTrade($db) {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        sendErrorResponse('Invalid CSRF token', 403);
        return;
    }
    
    // Get POST data
    $trade_id = trim($_POST['trade_id'] ?? '');
    $counterparty_id = (int)($_POST['counterparty_id'] ?? 0);
    $commodity_id = (int)($_POST['commodity_id'] ?? 0);
    $business_unit_id = (int)($_POST['business_unit_id'] ?? 1);
    $quantity = (float)($_POST['quantity'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $currency = trim($_POST['currency'] ?? 'USD');
    $trade_type = trim($_POST['trade_type'] ?? '');
    $contract_type = trim($_POST['contract_type'] ?? '');
    $settlement_date = trim($_POST['settlement_date'] ?? '');
    $margin_requirement = (float)($_POST['margin_requirement'] ?? 0);
    $exchange = trim($_POST['exchange'] ?? '');
    $contract_month = trim($_POST['contract_month'] ?? '');
    $strike_price = (float)($_POST['strike_price'] ?? 0);
    $option_type = trim($_POST['option_type'] ?? '');
    $premium = (float)($_POST['premium'] ?? 0);
    $status = trim($_POST['status'] ?? 'pending');
    
    // Validation
    $errors = [];
    
    if (empty($trade_id)) {
        $errors[] = 'Trade ID is required';
    } elseif (strlen($trade_id) < 3) {
        $errors[] = 'Trade ID must be at least 3 characters long';
    }
    
    if ($counterparty_id <= 0) {
        $errors[] = 'Valid counterparty is required';
    }
    
    if ($commodity_id <= 0) {
        $errors[] = 'Valid commodity/product is required';
    }
    
    if ($quantity <= 0) {
        $errors[] = 'Quantity must be greater than 0';
    }
    
    if ($price <= 0) {
        $errors[] = 'Price must be greater than 0';
    }
    
    if (empty($trade_type) || !in_array($trade_type, ['buy', 'sell', 'hedge'])) {
        $errors[] = 'Valid trade type is required (buy, sell, hedge)';
    }
    
    if (empty($contract_type) || !in_array($contract_type, ['futures', 'options', 'swaps', 'forwards'])) {
        $errors[] = 'Valid contract type is required (futures, options, swaps, forwards)';
    }
    
    if (empty($settlement_date) || !validateDate($settlement_date)) {
        $errors[] = 'Valid settlement date is required';
    }
    
    if (!in_array($status, ['pending', 'confirmed', 'executed', 'settled', 'cancelled'])) {
        $errors[] = 'Invalid status';
    }
    
    // Check if trade_id already exists
    $existingTrade = $db->fetchOne("SELECT id FROM financial_trades WHERE trade_id = ?", [$trade_id]);
    if ($existingTrade) {
        $errors[] = 'Trade ID already exists';
    }
    
    // Verify counterparty exists
    $counterparty = $db->fetchOne("SELECT id FROM counterparties WHERE id = ? AND status = 'active'", [$counterparty_id]);
    if (!$counterparty) {
        $errors[] = 'Invalid or inactive counterparty';
    }
    
    // Verify commodity exists
    $commodity = $db->fetchOne("SELECT id FROM products WHERE id = ? AND active_status = 'active'", [$commodity_id]);
    if (!$commodity) {
        $errors[] = 'Invalid or inactive commodity/product';
    }
    
    if (!empty($errors)) {
        sendErrorResponse(implode(', ', $errors), 400);
        return;
    }
    
    // Get current user ID
    $trader_id = getCurrentUserId();
    
    // Insert new financial trade
    $insertData = [
        'trade_id' => $trade_id,
        'counterparty_id' => $counterparty_id,
        'commodity_id' => $commodity_id,
        'business_unit_id' => $business_unit_id,
        'trader_id' => $trader_id,
        'quantity' => $quantity,
        'price' => $price,
        'currency' => $currency,
        'trade_type' => $trade_type,
        'contract_type' => $contract_type,
        'settlement_date' => $settlement_date,
        'margin_requirement' => $margin_requirement ?: null,
        'exchange' => $exchange ?: null,
        'contract_month' => $contract_month ?: null,
        'strike_price' => $strike_price ?: null,
        'option_type' => $option_type ?: null,
        'premium' => $premium ?: null,
        'status' => $status,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ];
    
    $newId = $db->insert('financial_trades', $insertData);
    
    if ($newId) {
        // Log activity
        logUserActivity($trader_id, 'create_financial_trade', "Created financial trade: {$trade_id}");
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Financial trade created successfully',
            'data' => ['id' => $newId, 'trade_id' => $trade_id]
        ]);
    } else {
        sendErrorResponse('Failed to create financial trade');
    }
}

/**
 * Handle PUT requests - update financial trade
 */
function handleUpdateFinancialTrade($db) {
    // Get JSON input for PUT requests
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        sendErrorResponse('Invalid JSON input', 400);
        return;
    }
    
    // Validate CSRF token
    if (!validateCSRFToken($input['csrf_token'] ?? '')) {
        sendErrorResponse('Invalid CSRF token', 403);
        return;
    }
    
    $trade_id = (int)($input['id'] ?? 0);
    
    if ($trade_id <= 0) {
        sendErrorResponse('Invalid trade ID', 400);
        return;
    }
    
    // Check if trade exists
    $existingTrade = $db->fetchOne("SELECT * FROM financial_trades WHERE id = ?", [$trade_id]);
    if (!$existingTrade) {
        sendErrorResponse('Financial trade not found', 404);
        return;
    }
    
    // Check permissions - only allow editing of own trades or if admin/manager
    $currentUser = getCurrentUserId();
    $currentRole = getCurrentUserRole();
    if ($existingTrade['trader_id'] != $currentUser && !in_array($currentRole, ['admin', 'manager'])) {
        sendErrorResponse('Insufficient permissions to edit this trade', 403);
        return;
    }
    
    // Build update data from input
    $updateData = [];
    $allowedFields = [
        'counterparty_id', 'commodity_id', 'business_unit_id', 'quantity', 'price', 
        'currency', 'trade_type', 'contract_type', 'settlement_date', 'margin_requirement',
        'exchange', 'contract_month', 'strike_price', 'option_type', 'premium', 'status'
    ];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateData[$field] = $input[$field];
        }
    }
    
    if (empty($updateData)) {
        sendErrorResponse('No valid fields to update', 400);
        return;
    }
    
    // Add updated timestamp
    $updateData['updated_at'] = date('Y-m-d H:i:s');
    
    // Validate the update data
    if (isset($updateData['quantity']) && $updateData['quantity'] <= 0) {
        sendErrorResponse('Quantity must be greater than 0', 400);
        return;
    }
    
    if (isset($updateData['price']) && $updateData['price'] <= 0) {
        sendErrorResponse('Price must be greater than 0', 400);
        return;
    }
    
    // Update the trade
    $success = $db->update('financial_trades', $updateData, 'id = ?', [$trade_id]);
    
    if ($success) {
        // Log activity
        logUserActivity($currentUser, 'update_financial_trade', "Updated financial trade ID: {$trade_id}");
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Financial trade updated successfully'
        ]);
    } else {
        sendErrorResponse('Failed to update financial trade');
    }
}

/**
 * Handle DELETE requests - delete financial trade
 */
function handleDeleteFinancialTrade($db) {
    // Get JSON input for DELETE requests
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        sendErrorResponse('Invalid JSON input', 400);
        return;
    }
    
    // Validate CSRF token
    if (!validateCSRFToken($input['csrf_token'] ?? '')) {
        sendErrorResponse('Invalid CSRF token', 403);
        return;
    }
    
    $trade_id = (int)($input['id'] ?? 0);
    
    if ($trade_id <= 0) {
        sendErrorResponse('Invalid trade ID', 400);
        return;
    }
    
    // Check if trade exists
    $existingTrade = $db->fetchOne("SELECT * FROM financial_trades WHERE id = ?", [$trade_id]);
    if (!$existingTrade) {
        sendErrorResponse('Financial trade not found', 404);
        return;
    }
    
    // Check permissions - only allow deletion by admin/manager or trade owner
    $currentUser = getCurrentUserId();
    $currentRole = getCurrentUserRole();
    if ($existingTrade['trader_id'] != $currentUser && !in_array($currentRole, ['admin', 'manager'])) {
        sendErrorResponse('Insufficient permissions to delete this trade', 403);
        return;
    }
    
    // Don't allow deletion of executed or settled trades
    if (in_array($existingTrade['status'], ['executed', 'settled'])) {
        sendErrorResponse('Cannot delete executed or settled trades', 400);
        return;
    }
    
    // Delete the trade
    $success = $db->delete('financial_trades', 'id = ?', [$trade_id]);
    
    if ($success) {
        // Log activity
        logUserActivity($currentUser, 'delete_financial_trade', "Deleted financial trade: {$existingTrade['trade_id']}");
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Financial trade deleted successfully'
        ]);
    } else {
        sendErrorResponse('Failed to delete financial trade');
    }
}


?> 