<?php
/**
 * Physical Sales API
 * Get physical sales data for trading module
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

// Handle different HTTP methods
$method = $_SERVER['REQUEST_METHOD'];

try {
    $db = getDB();

    if ($method === 'POST') {
        // Handle create new physical sale
        handleCreatePhysicalSale($db);
        return;
    }
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM physical_sales {$whereClause}";
    $totalResult = $db->fetchOne($countQuery, $params);
    $total = $totalResult['total'];
    
    // Get physical sales
    $query = "
        SELECT 
            ps.*,
            c.name as counterparty_name,
            p.product_name,
            bu.business_unit_name
        FROM physical_sales ps
        LEFT JOIN counterparties c ON ps.counterparty_id = c.id
        LEFT JOIN products p ON ps.product_id = p.id
        LEFT JOIN business_units bu ON ps.business_unit_id = bu.id
        {$whereClause}
        ORDER BY ps.created_at DESC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $sales = $db->fetchAll($query, $params);
    
    // Format data for frontend
    $formattedSales = [];
    foreach ($sales as $sale) {
        $formattedSales[] = [
            'id' => $sale['id'],
            'trade_id' => $sale['trade_id'],
            'counterparty_name' => $sale['counterparty_name'],
            'product_name' => $sale['product_name'],
            'quantity' => number_format($sale['quantity'], 2),
            'price' => $sale['price'],
            'currency' => $sale['currency'],
            'delivery_date' => $sale['delivery_date'],
            'delivery_location' => $sale['delivery_location'],
            'status' => $sale['status'],
            'created_at' => date('Y-m-d H:i', strtotime($sale['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedSales,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
    
} catch (Exception $e) {
    error_log("Physical sales API error: " . $e->getMessage());
    sendErrorResponse('Failed to load physical sales data');
}

function handleCreatePhysicalSale($db) {
    try {
        // Get POST data
        $trade_id = $_POST['trade_id'] ?? '';
        $counterparty_id = (int)($_POST['counterparty_id'] ?? 0);
        $product_id = (int)($_POST['product_id'] ?? 0);
        $quantity = (float)($_POST['quantity'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        $delivery_date = $_POST['delivery_date'] ?? '';
        $status = $_POST['status'] ?? 'pending';
        $location = $_POST['location'] ?? '';
        
        // Validation
        if (empty($trade_id) || $counterparty_id <= 0 || $product_id <= 0 || $quantity <= 0 || $price <= 0) {
            sendErrorResponse('All required fields must be provided');
            return;
        }
        
        // Check if trade_id already exists
        $existingStmt = $db->query("SELECT id FROM physical_sales WHERE trade_id = ?", [$trade_id]);
        if ($existingStmt->fetch()) {
            sendErrorResponse('Trade ID already exists');
            return;
        }
        
        // Get current user ID
        $trader_id = getCurrentUserId();
        $business_unit_id = 1; // Default business unit for now
        
        // Calculate total value
        $total_value = $quantity * $price;
        
        // Insert new physical sale
        $query = "
            INSERT INTO physical_sales (
                trade_id, counterparty_id, product_id, trader_id, business_unit_id,
                quantity, unit_of_measure, price, currency, delivery_location, 
                delivery_date, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ";
        
        $params = [
            $trade_id, $counterparty_id, $product_id, $trader_id, $business_unit_id,
            $quantity, 'bbl', $price, 'USD', $location, $delivery_date, $status
        ];
        
        $stmt = $db->query($query, $params);
        
        if ($stmt->rowCount() > 0) {
            // Get the created record
            $newId = $db->getPDO()->lastInsertId();
            
            // Log activity
            logUserActivity($trader_id, 'create_physical_sale', "Created physical sale: {$trade_id}");
            
            sendJSONResponse([
                'success' => true,
                'message' => 'Physical sale created successfully',
                'data' => ['id' => $newId, 'trade_id' => $trade_id]
            ]);
        } else {
            sendErrorResponse('Failed to create physical sale');
        }
        
    } catch (Exception $e) {
        error_log("Create physical sale error: " . $e->getMessage());
        sendErrorResponse('Failed to create physical sale: ' . $e->getMessage());
    }
}
?> 