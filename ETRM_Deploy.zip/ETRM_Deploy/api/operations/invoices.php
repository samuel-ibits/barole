<?php
/**
 * Invoices API
 * Handle CRUD operations for invoices
 */

require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json');

requireAuth();

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            handleGetInvoices($db);
            break;
        case 'POST':
            handleCreateInvoice($db);
            break;
        case 'PUT':
            handleUpdateInvoice($db);
            break;
        case 'DELETE':
            handleDeleteInvoice($db);
            break;
        default:
            sendErrorResponse('Method not allowed', 405);
    }

} catch (Exception $e) {
    error_log("Invoices API error: " . $e->getMessage());
    sendErrorResponse('Failed to process invoices request: ' . $e->getMessage());
}

/**
 * Handle GET requests - retrieve invoices
 */
function handleGetInvoices($db) {
    
    // Get parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    
    // Validate parameters
    $page = max(1, $page);
    $limit = max(1, min(100, $limit));
    $offset = ($page - 1) * $limit;
    
    // Build query
    $whereConditions = [];
    $params = [];
    
    if (!empty($status)) {
        $whereConditions[] = "status = ?";
        $params[] = $status;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM invoices {$whereClause}";
    $totalResult = $db->fetchOne($countQuery, $params);
    $total = $totalResult['total'];
    
    // Get invoices
    $query = "
        SELECT 
            i.*,
            c.name as counterparty_name
        FROM invoices i
        LEFT JOIN counterparties c ON i.counterparty_id = c.id
        {$whereClause}
        ORDER BY i.created_at DESC
        LIMIT ? OFFSET ?
    ";
    
    $params[] = $limit;
    $params[] = $offset;
    
    $invoices = $db->fetchAll($query, $params);
    
    // Format data for frontend
    $formattedInvoices = [];
    foreach ($invoices as $invoice) {
        $formattedInvoices[] = [
            'id' => $invoice['id'],
            'invoice_number' => $invoice['invoice_number'],
            'counterparty_name' => $invoice['counterparty_name'],
            'amount' => number_format($invoice['amount'], 2),
            'currency' => $invoice['currency'],
            'due_date' => $invoice['due_date'],
            'status' => $invoice['status'],
            'created_at' => date('Y-m-d H:i', strtotime($invoice['created_at']))
        ];
    }
    
    // Prepare response
    $response = [
        'success' => true,
        'data' => $formattedInvoices,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'total_pages' => ceil($total / $limit)
        ]
    ];
    
    sendJSONResponse($response);
}

/**
 * Handle POST requests - create new invoice
 */
function handleCreateInvoice($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $errors = [];
    $requiredFields = ['invoice_number', 'trade_id', 'counterparty_id', 'amount', 'currency', 'invoice_date', 'due_date'];
    
    foreach ($requiredFields as $field) {
        if (empty($input[$field])) {
            $errors[] = "Field '$field' is required";
        }
    }
    
    // Validate specific field formats
    $invoice_number = trim($input['invoice_number'] ?? '');
    $trade_id = trim($input['trade_id'] ?? '');
    $counterparty_id = intval($input['counterparty_id'] ?? 0);
    $amount = floatval($input['amount'] ?? 0);
    $currency = trim($input['currency'] ?? '');
    $invoice_date = trim($input['invoice_date'] ?? '');
    $due_date = trim($input['due_date'] ?? '');
    $status = trim($input['status'] ?? 'draft');
    $description = trim($input['description'] ?? '');
    $line_items = $input['line_items'] ?? [];
    
    // Validate invoice number format
    if (!preg_match('/^INV[0-9]{4}[A-Z0-9]+$/', $invoice_number)) {
        $errors[] = 'Invoice number must follow format: INV followed by numbers and letters (e.g., INV2024001)';
    }
    
    // Validate amount
    if ($amount <= 0) {
        $errors[] = 'Amount must be greater than 0';
    }
    
    // Validate currency (3 letters)
    if (!preg_match('/^[A-Z]{3}$/', $currency)) {
        $errors[] = 'Currency must be a 3-letter code (e.g., USD)';
    }
    
    // Validate dates
    if (!validateDate($invoice_date)) {
        $errors[] = 'Invoice date must be in YYYY-MM-DD format';
    }
    
    if (!validateDate($due_date)) {
        $errors[] = 'Due date must be in YYYY-MM-DD format';
    }
    
    // Validate status
    if (!in_array($status, ['draft', 'sent', 'paid', 'overdue', 'cancelled'])) {
        $errors[] = 'Valid status is required';
    }
    
    if (!empty($errors)) {
        sendErrorResponse('Validation failed: ' . implode(', ', $errors), 400);
        return;
    }
    
    try {
        // Check if invoice_number already exists
        $existingInvoice = $db->fetchOne("SELECT id FROM invoices WHERE invoice_number = ?", [$invoice_number]);
        if ($existingInvoice) {
            sendErrorResponse('Invoice number already exists', 400);
            return;
        }
        
        // Insert new invoice
        $query = "
            INSERT INTO invoices (
                invoice_number, trade_id, counterparty_id, amount, currency,
                invoice_date, due_date, status, description, line_items,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ";
        
        $params = [
            $invoice_number, $trade_id, $counterparty_id, $amount, $currency,
            $invoice_date, $due_date, $status, $description, 
            !empty($line_items) ? json_encode($line_items) : null
        ];
        
        $result = $db->execute($query, $params);
        
        if ($result) {
            $invoiceId = $db->getConnection()->lastInsertId();
            sendJSONResponse([
                'success' => true,
                'message' => 'Invoice created successfully',
                'data' => ['id' => $invoiceId, 'invoice_number' => $invoice_number]
            ], 201);
        } else {
            sendErrorResponse('Failed to create invoice');
        }
        
    } catch (Exception $e) {
        error_log("Create invoice error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle PUT requests - update existing invoice
 */
function handleUpdateInvoice($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid invoice ID is required', 400);
        return;
    }
    
    // Check if invoice exists
    $existingInvoice = $db->fetchOne("SELECT * FROM invoices WHERE id = ?", [$id]);
    if (!$existingInvoice) {
        sendErrorResponse('Invoice not found', 404);
        return;
    }
    
    // Build update query with only provided fields
    $updateFields = [];
    $params = [];
    
    $allowedFields = [
        'trade_id', 'counterparty_id', 'amount', 'currency', 'invoice_date',
        'due_date', 'status', 'description', 'line_items'
    ];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            if ($field === 'line_items') {
                $updateFields[] = "$field = ?";
                $params[] = !empty($input[$field]) ? json_encode($input[$field]) : null;
            } else {
                $updateFields[] = "$field = ?";
                $params[] = $input[$field];
            }
        }
    }
    
    if (empty($updateFields)) {
        sendErrorResponse('No fields to update', 400);
        return;
    }
    
    // Add updated_at timestamp
    $updateFields[] = "updated_at = CURRENT_TIMESTAMP";
    $params[] = $id;
    
    try {
        $query = "UPDATE invoices SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $result = $db->execute($query, $params);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Invoice updated successfully'
            ]);
        } else {
            sendErrorResponse('Failed to update invoice');
        }
        
    } catch (Exception $e) {
        error_log("Update invoice error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}

/**
 * Handle DELETE requests - delete invoice
 */
function handleDeleteInvoice($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? 0);
    
    if ($id <= 0) {
        sendErrorResponse('Valid invoice ID is required', 400);
        return;
    }
    
    try {
        // Check if invoice exists
        $existingInvoice = $db->fetchOne("SELECT id, status FROM invoices WHERE id = ?", [$id]);
        if (!$existingInvoice) {
            sendErrorResponse('Invoice not found', 404);
            return;
        }
        
        // Prevent deletion of paid invoices
        if ($existingInvoice['status'] === 'paid') {
            sendErrorResponse('Cannot delete paid invoices', 400);
            return;
        }
        
        $result = $db->execute("DELETE FROM invoices WHERE id = ?", [$id]);
        
        if ($result) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Invoice deleted successfully'
            ]);
        } else {
            sendErrorResponse('Failed to delete invoice');
        }
        
    } catch (Exception $e) {
        error_log("Delete invoice error: " . $e->getMessage());
        sendErrorResponse('Database error occurred');
    }
}
?> 