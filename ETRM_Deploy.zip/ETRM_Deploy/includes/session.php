<?php
/**
 * Session Management
 * ETRM System - Secure session handling
 */

// Load configuration
require_once CONFIG_PATH . '/app.php';

/**
 * Initialize secure session
 */
function initSecureSession() {
    // Only initialize if session hasn't been started
    if (session_status() === PHP_SESSION_NONE) {
        // Set secure session parameters
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', SESSION_SECURE ? 1 : 0);
        ini_set('session.cookie_samesite', 'Strict');
        
        // Set session name
        session_name(SESSION_NAME);
        
        // Set session cookie parameters
        session_set_cookie_params(
            SESSION_LIFETIME,
            SESSION_PATH,
            SESSION_DOMAIN,
            SESSION_SECURE,
            SESSION_HTTP_ONLY
        );
        
        // Start session
        session_start();
    }
    
    // Regenerate session ID periodically for security
    if (!isset($_SESSION['last_regeneration'])) {
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 300) { // 5 minutes
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
    
    // Set session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['last_activity'] = time();
}

/**
 * Create user session
 */
function createUserSession($userId, $username, $role) {
    try {
        $db = getDB();
        
        // Set session variables
        $_SESSION['user_id'] = $userId;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role;
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();
        
        // Update last login
        $db->update('users', 
            ['last_login' => date('Y-m-d H:i:s')], 
            'id = ?', 
            [$userId]
        );
        
        return true;
    } catch (Exception $e) {
        error_log("Failed to create user session: " . $e->getMessage());
        return false;
    }
}

/**
 * Validate user session
 */
function validateUserSession() {
    // Simple validation using only PHP sessions for now
    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
        return false;
    }
    
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['username']) || !isset($_SESSION['role'])) {
        return false;
    }
    
    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
        destroyUserSession();
        return false;
    }
    
    // Update last activity
    $_SESSION['last_activity'] = time();
    
    return true;
}

/**
 * Destroy user session
 */
function destroyUserSession() {
    if (isset($_SESSION['session_token'])) {
        try {
            $db = getDB();
            $db->query(
                "DELETE FROM user_sessions WHERE session_token = ?",
                [$_SESSION['session_token']]
            );
        } catch (Exception $e) {
            error_log("Failed to destroy user session: " . $e->getMessage());
        }
    }
    
    // Clear session variables
    session_unset();
    session_destroy();
    
    // Start new session
    session_start();
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current username
 */
function getCurrentUsername() {
    return $_SESSION['username'] ?? null;
}

/**
 * Get current user role
 */
function getCurrentUserRole() {
    return $_SESSION['role'] ?? null;
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return validateUserSession();
}

/**
 * Check if user has specific role
 */
function hasRole($role) {
    if (!isLoggedIn()) {
        return false;
    }
    
    $userRole = getCurrentUserRole();
    
    // Role hierarchy (admin has all permissions)
    if ($userRole === ROLE_ADMIN) {
        return true;
    }
    
    return $userRole === $role;
}

/**
 * Check if user has any of the specified roles
 */
function hasAnyRole($roles) {
    if (!isLoggedIn()) {
        return false;
    }
    
    $userRole = getCurrentUserRole();
    
    // Admin has all permissions
    if ($userRole === ROLE_ADMIN) {
        return true;
    }
    
    return in_array($userRole, $roles);
}

/**
 * Require authentication
 */
function requireAuth() {
    if (!isLoggedIn()) {
        if (isAjaxRequest()) {
            sendErrorResponse('Authentication required', 401);
        } else {
            header('Location: ' . BASE_URL . '/login.php');
            exit;
        }
    }
}

/**
 * Require specific role
 */
function requireRole($role) {
    requireAuth();
    
    if (!hasRole($role)) {
        if (isAjaxRequest()) {
            sendErrorResponse('Insufficient permissions', 403);
        } else {
            header('Location: ' . BASE_URL . '/error.php?code=403');
            exit;
        }
    }
}

/**
 * Require any of the specified roles
 */
function requireAnyRole($roles) {
    requireAuth();
    
    if (!hasAnyRole($roles)) {
        if (isAjaxRequest()) {
            sendErrorResponse('Insufficient permissions', 403);
        } else {
            header('Location: ' . BASE_URL . '/error.php?code=403');
            exit;
        }
    }
}

/**
 * Get user permissions
 */
function getUserPermissions() {
    if (!isLoggedIn()) {
        return [];
    }
    
    try {
        $db = getDB();
        $user = $db->fetchOne(
            "SELECT permissions FROM users WHERE id = ?",
            [getCurrentUserId()]
        );
        
        if ($user && $user['permissions']) {
            return json_decode($user['permissions'], true) ?: [];
        }
        
        return [];
    } catch (Exception $e) {
        error_log("Failed to get user permissions: " . $e->getMessage());
        return [];
    }
}

/**
 * Check if user has specific permission
 */
function hasPermission($permission) {
    $permissions = getUserPermissions();
    return in_array($permission, $permissions);
}

/**
 * Get role permissions
 */
function getRolePermissions($role) {
    $permissions = [
        ROLE_ADMIN => [
            'user_manage', 'system_config', 'audit_view', 'report_generate',
            'trade_create', 'trade_edit', 'trade_delete', 'trade_approve',
            'master_data_manage', 'risk_manage', 'dashboard_configure'
        ],
        ROLE_MANAGER => [
            'trade_approve', 'report_generate', 'risk_view', 'dashboard_configure',
            'user_view', 'master_data_view'
        ],
        ROLE_TRADER => [
            'trade_create', 'trade_edit', 'trade_view', 'risk_view',
            'dashboard_configure', 'master_data_view'
        ],
        ROLE_ANALYST => [
            'trade_view', 'risk_view', 'report_generate', 'dashboard_configure',
            'master_data_view'
        ],
        ROLE_VIEWER => [
            'trade_view', 'risk_view', 'dashboard_view', 'master_data_view'
        ]
    ];
    
    return $permissions[$role] ?? [];
}

/**
 * Initialize session on page load
 */
initSecureSession();
?> 