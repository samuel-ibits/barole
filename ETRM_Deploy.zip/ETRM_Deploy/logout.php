<?php
/**
 * ETRM System - Logout Page
 * User logout and session cleanup
 */

// Load configuration
require_once 'config/app.php';

// Logout user
logoutUser();

// Redirect to login page
header('Location: login.php');
exit;
?> 